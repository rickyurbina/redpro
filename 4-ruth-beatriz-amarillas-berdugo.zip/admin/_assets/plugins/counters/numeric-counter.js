$(function(){
	$('.counter').countUp();
});