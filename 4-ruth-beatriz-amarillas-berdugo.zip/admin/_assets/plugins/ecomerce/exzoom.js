$(function(){
	 $("#exzoom").exzoom({
		   autoPlay: false,
	   });
	 $("#exzoom").removeClass('hidden')
});