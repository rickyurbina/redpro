$(function(e) {
	$('#example').DataTable();
	$('#example2').DataTable();
} );
